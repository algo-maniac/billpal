import { Group } from "@/models/group.model";
import { NextResponse } from "next/server";
import { connectDB } from "@/lib/mongodb";

export async function POST(req) {
  try {
    // Connect to the database
    await connectDB();

    // Extract data from the request body
    const { groupId, transactionId } = await req.json();
    console.log(groupId, transactionId);

    // Find the group by groupId
    const group = await Group.findOne({ _id: groupId });
    console.log(group);

    if (!group) {
      return NextResponse.json({ status: 404, message: "Group not found" });
    }

    // Remove the transaction from transactionArray

    console.log(group.transactionArray);

    await Group.findOneAndUpdate(
      { _id: groupId },
      { $pull: { transactionArray: transactionId } },
      { new: true }
    );
    // Save the updated group
    await group.save();

    const gp = await Group.findOne({ _id: groupId });
    console.log(gp);
    console.log(group.transactionArray);

    // Send a success response
    const updatedGroup = await Group.findOne({ _id: groupId }).transactionArray;
    return NextResponse.json({
      status: 200,
      message: "Transaction removed successfully",
      updatedGroup,
    });
  } catch (error) {
    console.error("Error removing transaction:", error);
    return NextResponse.json({ status: 500, message: "Internal Server Error" });
  }
}
